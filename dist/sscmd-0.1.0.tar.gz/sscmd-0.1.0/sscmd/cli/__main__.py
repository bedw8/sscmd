from typing import Optional
import typer

from . import *

app()
        
